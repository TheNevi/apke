package com.example.apke;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.regex.Pattern;

public class HelloController {
    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");

    @FXML private TextField nameField;
    @FXML private TextField surnameField;
    @FXML private TextField emailField;
    @FXML private TextField postalField;

    @FXML private RadioButton maleRadio;
    @FXML private RadioButton femaleRadio;

    @FXML private CheckBox check1;
    @FXML private CheckBox check2;
    @FXML private CheckBox check3;

    @FXML private Spinner<Integer> ageSpinner;
    @FXML private ChoiceBox<String> choiceBox;

    @FXML private Slider sliderH;
    @FXML private Slider sliderV;

    private ToggleGroup genderGroup;

    @FXML
    public void initialize() {
        genderGroup = new ToggleGroup();
        maleRadio.setToggleGroup(genderGroup);
        femaleRadio.setToggleGroup(genderGroup);
        maleRadio.setSelected(true);
        ageSpinner.setValueFactory(
                new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 120, 18)
        );
        choiceBox.getItems().addAll("Letni", "Zimowy");
        choiceBox.getSelectionModel().selectFirst();
    }

    @FXML
    private void onSubmit() {

        String name = nameField.getText().trim();
        String surname = surnameField.getText().trim();
        String email = emailField.getText().trim();
        String postal = postalField.getText().trim();
        if (name.isEmpty() || surname.isEmpty() || email.isEmpty() || postal.isEmpty()) {
            new Alert(Alert.AlertType.ERROR,
                    "Uzupełnij wszystkie pola!")
                    .show();
            return;
        }
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            new Alert(Alert.AlertType.ERROR,
                    "Niepoprawny adres e-mail")
                    .show();
            return;
        }
        if (!postal.matches("\\d{2}-\\d{3}")) {
            new Alert(Alert.AlertType.ERROR,
                    "Kod pocztowy musi mieć format NN-NNN")
                    .show();
            return;
        }
        String gender =
                ((RadioButton) genderGroup.getSelectedToggle()).getText();
        String result = "Imię: " + name + "\n" +
                        "Nazwisko: " + surname + "\n" +
                        "Płeć: " + gender + "\n" +
                        "Jaki pokój?: " +
                        (check1.isSelected() ? "Jednoosobowy " : "") +
                        (check2.isSelected() ? "Dwuosobowy " : "") +
                        (check3.isSelected() ? "Rodzinny " : "") + "\n" +
                        "Ile masz lat?: " + ageSpinner.getValue() + "\n" +
                        "Rodzaj kurortu: " + choiceBox.getValue() + "\n" +
                        "Ile dni: " + sliderH.getValue() + "\n" +
                        "Ocena: " + sliderV.getValue();
        new Alert(Alert.AlertType.INFORMATION, result).show();
    }
}