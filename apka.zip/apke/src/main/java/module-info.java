module com.example.apke {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.apke to javafx.fxml;
    exports com.example.apke;
}